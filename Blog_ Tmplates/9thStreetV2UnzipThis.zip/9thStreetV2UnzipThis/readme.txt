Thank you for downloading the is beautiful Blogger template

https://logwork.com/blog/how-to-install-blogger-template/

1. Simply unzip/open your downloaded zip file.
2. You will find the following:
	- .xml file (your blogger template)
	- Blogger template installation (shortcut link)
	- How to add your photo with circular effect (text file)
	- How to add social media icons (text file)
	- Social media icons

3. Please make sure your date format is displaying correctly for each post. You can always change the format of the date :

Go to: Settings  �  Language and formatting -> Date Header Format. 

Then click on the Save Settings button on the top right corner and the date will display correctly.


-------------------------------

Copyright & Legal Information

LICENSE: You may use this template on your personal or commercial website. You cannot sell, share or distribute the code or this template. ThemeFashion owns all of the copyrights to the design and code of the template. You may not remove the "Design by ThemeFashion" link from the bottom footer.


Please contact me anytime if you have any questions.

Thanks and Enjoy your new template :)

Bilal
ThemeFashion.