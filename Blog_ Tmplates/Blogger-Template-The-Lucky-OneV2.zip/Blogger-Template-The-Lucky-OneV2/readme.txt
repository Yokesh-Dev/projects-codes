Thank you for downloading this beautiful Blogger template :)

https://logwork.com/blog/how-to-install-blogger-template/

1. Simply unzip/open your downloaded zip file.
2. You will find the following:
	- .xml file (your blogger template)
	- Blogger template installation (shortcut link)
	- How to add your photo (text file)
	- How to add social media icons (text file)
	- How to add custom search box (text file)
	- Social media icons

3. How to Install this template: https://logwork.com/blog/how-to-install-blogger-template/
-------------------------------

Copyright & Legal Information

LICENSE: You may use this template on your personal or commercial website. You cannot sell, share or distribute the code or this template. ThemeFashion owns all of the copyrights to the design and code of the template. You may not remove the "Design by ThemeFashion" link from the bottom footer.


Please contact me anytime if you have any questions.

Thanks and Enjoy your new template :)

Bilal
ThemeFashion.