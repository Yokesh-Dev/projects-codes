let myLeads = []
const inputEl = document.getElementById("input-el")
const inputBtn = document.getElementById("input-btn")
const ulEl = document.getElementById("ul-el")


inputBtn.addEventListener("click", function() {
    myLeads.push(inputEl.value)
    document.getElementById('input-el').value = '';
    renderLeads()
    let input1 = document.getElementById('input-El');
input1.value = ""; 
})

function renderLeads() {
    let listItems = ""
    for (let i = 0; i < myLeads.length; i++) {

        listItems += `
                   <li>
                    <a target ='blank' href ='${myLeads[i]}'> 
                    ${myLeads[i]}
                    </a>
                    </li>`
    } 
    ulEl.innerHTML = listItems  

}



