emailjs.init("Q0WQ3CCC-zVmXoFzG");

document.getElementById("contact-form").addEventListener("submit", function (event) {
    event.preventDefault();

    // Get form data
    const params = {
        from_name: document.getElementById("user-name").value,
        from_mail: document.getElementById("emailid").value,
        phone_no: document.getElementById("phone").value,
        message: document.getElementById("message").value
    }

    // Send email using EmailJS
    emailjs.send("service_1apgfii", "template_wv09bar", params)
        .then(function (response) {
            // Email sent successfully
            alert("Form submitted successfully!");
            document.getElementById("user-name").value =null;
            document.getElementById("emailid").value =null;
            document.getElementById("phone").value =null;
            document.getElementById("message").value =null;
        }, function (error) {
            // Email sending failed
            alert("Form submission failed. Please try again.");
        });
});
