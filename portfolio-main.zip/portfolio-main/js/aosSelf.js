const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach((entry) => {
        console.log(entry);
        if (!entry.isIntersecting) {
            entry.target.classList.remove('show');
            // return;
        }
        // else if (!entry.isIntersecting) {
        //     entry.target.classList.remove('show');
        // }
        else {
            entry.target.classList.add('show');
            // observer.unobserve(entry.target)
            // return;
        }
    })
}, { rootMargin: "-50px 0px 0px 0px", threshold: 0 });

const hiddenLeft = document.querySelectorAll('.hiddenLeft');
const hiddenRight = document.querySelectorAll('.hiddenRight')
const hiddenUp1 = document.querySelectorAll('.hiddenUp1')
const hiddenUp2 = document.querySelectorAll('.hiddenUp2')
const hiddenUp3 = document.querySelectorAll('.hiddenUp3')
// const skillItem = document.querySelectorAll('.skill-item')



hiddenLeft.forEach((el) => observer.observe(el));
hiddenRight.forEach((el) => observer.observe(el));
hiddenUp1.forEach((el) => observer.observe(el));
hiddenUp2.forEach((el) => observer.observe(el));
hiddenUp3.forEach((el) => observer.observe(el));
// skillItem.forEach((el) => observer.observe(el));

