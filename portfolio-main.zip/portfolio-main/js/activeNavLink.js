
// hover active nav link

let section = document.querySelectorAll('.sec');
let menuOption = document.querySelectorAll('#menu-list>.link');

window.onscroll = () => {
    section.forEach(sec => {
        let top = window.scrollY;
        let offset = sec.offsetTop - 150;
        let height = sec.offsetHeight;
        let id = sec.getAttribute('id');

        if (top >= offset && top < offset + height) {
            menuOption.forEach(links => {
                links.classList.remove('active-tab');
                document.querySelector('#menu-list a[href*=' + id + ']').classList.add('active-tab')
            })
        }
    })
}
