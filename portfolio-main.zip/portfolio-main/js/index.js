// const { constants } = require("buffer");

const course = document.getElementById("courses-btn");
const experience = document.getElementById("experience-btn");
// alert("Hii");


// Preloader Starts

window.addEventListener('load', function () {
  // Show the preloader for 5 seconds
  const preloader = document.getElementById('preloader');
  setTimeout(function () {
    preloader.classList.add('hide-preloader');
  }, 3000); // 5000 milliseconds = 5 seconds
});

// preloader Ends


// const observer = new IntersectionObserver((entries) => {
//   entries.forEach((entry) => {
//     console.log(entry);
//     if (entry.isIntersecting) {
//       entry.target.classList.add('show');
//     } else {
//       entry.target.classList.remove('show');
//       // entry.target.classList.add('hidden');
//     }
//   })
// });

// const hiddenElement = document.querySelectorAll('.hidden');
// hiddenElement.forEach((el) => observer.observe(el));

course.addEventListener("click", function () {
  // alert("course");
  course.classList.add("tooglebtn");
  experience.classList.remove("tooglebtn");
  document.getElementById("experience-content").style.display = "none";
  document.getElementById("course-content").style.display = "flex";
});

experience.addEventListener("click", function () {
  // alert("Experience");
  experience.classList.add("tooglebtn");
  course.classList.remove("tooglebtn");
  document.getElementById("course-content").style.display = "none";
  document.getElementById("experience-content").style.display = "block";
});

var TxtType = function (el, toRotate, period) {
  this.toRotate = toRotate;
  this.el = el;
  this.loopNum = 0;
  this.period = parseInt(period, 10) || 2000;
  this.txt = '';
  this.tick();
  this.isDeleting = false;
};

TxtType.prototype.tick = function () {
  var i = this.loopNum % this.toRotate.length;
  var fullTxt = this.toRotate[i];

  if (this.isDeleting) {
    this.txt = fullTxt.substring(0, this.txt.length - 1);
  } else {
    this.txt = fullTxt.substring(0, this.txt.length + 1);
  }

  this.el.innerHTML = '<span class="wrap">' + this.txt + '</span>';

  var that = this;
  var delta = 200 - Math.random() * 100;

  if (this.isDeleting) { delta /= 2; }

  if (!this.isDeleting && this.txt === fullTxt) {
    delta = this.period;
    this.isDeleting = true;
  } else if (this.isDeleting && this.txt === '') {
    this.isDeleting = false;
    this.loopNum++;
    delta = 500;
  }

  setTimeout(function () {
    that.tick();
  }, delta);
};

window.onload = function () {
  var elements = document.getElementsByClassName('typewrite');
  for (var i = 0; i < elements.length; i++) {
    var toRotate = elements[i].getAttribute('data-type');
    var period = elements[i].getAttribute('data-period');
    if (toRotate) {
      new TxtType(elements[i], JSON.parse(toRotate), period);
    }
  }
  // INJECT CSS
  var css = document.createElement("style");
  css.type = "text/css";
  css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
  document.body.appendChild(css);
};


// const projectCard = document.querySelectorAll('.project-card')

// menu toggles

const menu = document.getElementById("menu");
const nav = document.querySelector("nav")
menu.addEventListener("click", () => {
  console.log("toogled");
  nav.classList.toggle("hidden-menu");

})
// Function to prevent right-click
function preventRightClick(event) {
  event.preventDefault();
}

// Attach the contextmenu event listener to the document
document.addEventListener('contextmenu', preventRightClick);

// Change the favicon and title for the active tab
function setFaviconAndTitle(active) {
  const favicon = document.getElementById('favicon');
  const title = document.getElementById('title');

  if (active) {
    favicon.href = './image/web-flavicon.ico'; // Set the active favicon
    title.innerText = 'Balaji | Portfolio'; // Set the active title
  } else {
    favicon.href = './image/coder_sleeping.ico'; // Set the default favicon
    title.innerText = 'Hey Comeback🙇‍♂️🙇‍♂️'; // Set the default title
  }
}

// Detect if the tab is active or not
document.addEventListener('visibilitychange', function () {
  setFaviconAndTitle(!document.hidden);
});

// Initial call to set favicon and title based on the current tab state
setFaviconAndTitle(!document.hidden);

